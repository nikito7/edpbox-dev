#include "automation.h"
#include "esphome/core/log.h"

namespace esphome {
namespace fan {

static const char *TAG = "fan.automation";

}  // namespace fan
}  // namespace esphome
