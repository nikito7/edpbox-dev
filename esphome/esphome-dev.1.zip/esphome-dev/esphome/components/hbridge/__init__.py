import esphome.codegen as cg

hbridge_ns = cg.esphome_ns.namespace("hbridge")
