CODEOWNERS = ["@esphome/core"]
