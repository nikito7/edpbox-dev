import esphome.codegen as cg

CODEOWNERS = ["@esphome/core"]
gpio_ns = cg.esphome_ns.namespace("gpio")
